---
layout: post
[//]: # (this stays "post")

title: "*Life Lessons - Fight the urger to be average*"
[//]: # (this is where you put your title. make sure your title is the same name as the file)

subtitle: "All those gritty adjectives in one phrase..."
[//]: # (this is where you put your subtitle. It appears in light grey under the title currently and underneath post on blog post index listing)

date: 2017-06-14
[//]: # (date probably won't be used long-term, but just add it if you want)

image: 
[//]: # (this is the image that will appear on the blog index page. it'll be a fixed dimension for all images used. I may have to have 2 images; one for the blog index page and one for the header of the post itself)

image-description: 
[//]: # (alt tag for the blog index page image. accessibility!)

published: true
[//]: # (can be true or false. if true, the post will show up on the blog index page, if not, it won't.)

---

I, and many others, had this mentor named Lamont Toliver. He was my mentor during my time @ UMBC in 2008-2012.

Bull-headed and aloof in my first interactions with him, I'm young guy and instinctually have the "oh, he's just another old man trying to tell me what to do via inspiration quotes."

But then he decides to check me on the menial-est of recreational activity. This wasn't even particularly a turning point in my perspective of him, but more so a "wait, is this what life is?".

I was skating prior to entering college and meeting Mr. Toliver. 

Mr. Toliver had many Toliverisms, as they were labeled, all of which I initially (and bull-headedly) thought were torn from pages in books. The one that stuck with me most, the one that was most salient, was the first one I ever remember him saying. Truly the first words I ever remember hearing from him. Our scholarship class was in an auditorium during what I think was the first or second week of our summer bridge program. For some reason, I never noticed this man in the room, but [insert your favorite "this guy was a 'his presence must be felt' type of dude" quote here]. He was in the back. It was right after some instructions were given to us about how the day or next few days would be going by. He then gave a speech. From the back of the auditorium. Neck(s) craning back to hear what he was saying (may have solely been my neck only for all I know).

Within his speech he said "Fight the urge to be average."

I had no initial reaction to it then, but 10 years later, I vividly remember this moment. I just carried that notion inherently and instinctually through college and afterwards, when I'm no longer in an environment where I basically felt enveloped by the notion, I had to fight the urge to be average on my own.

Mr. Toliver really teed it up in my mind, and continued to do so in our interactions during my time @ UMBC, where he was my academic advisor for my junior year and 1st semester of my senior year. 

Mr. Toliver passed during my senior year. Undoubtedly the


Link to his words: http://meyerhoffalumni.org/2015/02/fight-the-urge-to-be-average/