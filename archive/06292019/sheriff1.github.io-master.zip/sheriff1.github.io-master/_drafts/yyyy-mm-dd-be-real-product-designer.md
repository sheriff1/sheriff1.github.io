---
layout: post

title: "*Be real, product designer*"

date: 2018-02-16

image: appfolio_button.png

image-description: description of this image

published: false
---

Be real product designer

Time to start my contrarianism.

- Not everything can be "pleasurable", "delightful", etc
- Not all work is visual
- All work can tell a story, so tell your story honestly
	- My main portfolio project goal was to maintain success.
