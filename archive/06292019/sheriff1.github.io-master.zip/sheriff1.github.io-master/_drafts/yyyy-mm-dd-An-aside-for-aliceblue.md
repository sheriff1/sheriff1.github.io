---
layout: post

title: "*An aside for aliceblue*"

date: 2018-02-16

image: appfolio_button.png

image-description: description of this image

published: false
---

- Remade my portfolio
	- I found myself in a "flow" when working on it this time around vs. other times

- I made it more authentic

- I stole like an artist - my portfolio is no different visually than the hundreds/thousands that already exist, and it doesn't need to be

- Lost my old portfolio
	- Now want to make diligent effort to not do that again

- aliceblue is coincidentally a dope color
