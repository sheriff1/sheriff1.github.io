---
layout: post

title: "Open Application to Creative Circle"

subtitle: "This is my opportunity to get in on the ground floor..."

date: 2019-03-02

tags: "design life"

---

## This is my unsolicited application to join/create a creative circle and/or group chat.

I’m trying to network about when it’s best to use specific spices and shit like parsley and chives and creating media. I won’t post hella memes cuz I’m too slow on that, I’m more of a “why” person than a “yes” person, and I’m not into too much sensationalization.

I will admit when I don’t know what’s going on or what things mean.

I watch NBA and footy innit.

I close conversations by saying “peace” still and will do into the next century.

I can provide website design assistance.

I'll buy your product at full-price and volunteer to help you accomplish your goals.

I wanna talk about purpose, who you are, and how you’ve become who you are. I want to be around when you create, and I want you to be around when I create, digitally or physically. Let’s be great together.

References upon request.

👍🏿✌🏿